package net.stark.uuidpin;

import com.google.inject.Inject;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.player.GameProfileRequestEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.util.GameProfile;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Plugin(id = "uuidpin", name = "UuidPin", version = "1.0.0", authors = {"STARK NETWORK"})
public class UuidPin {

    private final Logger logger;
    private final Path dir;
    private final Map<String, UUID> map = new HashMap<>();

    @Inject
    public UuidPin(Logger logger, @DataDirectory Path dir) {
        this.logger = logger;
        this.dir = dir;
    }

    @Subscribe
    public void onInit(ProxyInitializeEvent e) {
        try {
            Files.createDirectories(dir);
            Path file = dir.resolve("uuids.csv");
            if (!Files.exists(file)) {
                Files.writeString(file, "# name,uuid  (one per line)\n", StandardCharsets.UTF_8);
            }
            try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    String[] p = line.split(",");
                    if (p.length < 2) continue;
                    String name = p[0].trim().toLowerCase();
                    if (name.equals("username") || name.equals("name")) continue;
                    try {
                        map.put(name, UUID.fromString(p[1].trim()));
                    } catch (IllegalArgumentException ex) {
                        logger.warn("Bad UUID line: {}", line);
                    }
                }
            }
            logger.info("UuidPin loaded {} pinned UUIDs.", map.size());
        } catch (Exception ex) {
            logger.error("Failed to load uuids.csv", ex);
        }
    }

    @Subscribe(order = PostOrder.LAST)
    public void onProfile(GameProfileRequestEvent e) {
        String name = e.getUsername();
        UUID uuid = map.get(name.toLowerCase());
        if (uuid == null) {
            uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        }
        GameProfile base = e.getGameProfile();
        e.setGameProfile(base.withId(uuid));
    }
}
